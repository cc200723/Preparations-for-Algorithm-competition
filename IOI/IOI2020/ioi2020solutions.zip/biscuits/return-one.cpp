#include "biscuits.h"
#include <vector>

long long count_tastiness(long long x, std::vector<long long> a) {
    return 1;
}
