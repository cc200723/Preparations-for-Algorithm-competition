#include "plants.h"

// just for testing i/o speed

void init(int k, std::vector<int> r) {
    return;
}

int compare_plants(int x, int y) {
    return 0;
}
