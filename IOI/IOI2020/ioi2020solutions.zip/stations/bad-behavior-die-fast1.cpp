#include "stations.h"
#include <vector>
#include <cstdlib>

std::vector<int> label(int n, int k, std::vector<int> u, std::vector<int> v) {
	exit(0);
	return {};
}

int find_next_station(int s, int t, std::vector<int> c) {
	return c[0];
}
