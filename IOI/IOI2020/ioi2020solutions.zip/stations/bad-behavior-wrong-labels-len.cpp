#include "stations.h"
#include <vector>

std::vector<int> label(int n, int k, std::vector<int> u, std::vector<int> v) {
	std::vector<int> labels(n+n%3);
	return labels;
}

int find_next_station(int s, int t, std::vector<int> c) {
	return c[0];
}
