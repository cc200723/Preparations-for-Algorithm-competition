#include "tickets.h"
#include <vector>

long long find_maximum(int k, std::vector<std::vector<int>> x) {
	allocate_tickets(x);
	allocate_tickets(x);
	return 1;
}
