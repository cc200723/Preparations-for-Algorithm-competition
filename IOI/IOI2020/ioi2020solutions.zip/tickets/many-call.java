public class tickets {
	long find_maximum(int k, int[][] x) {
		grader.allocate_tickets(x);
		grader.allocate_tickets(x);
		return 1;
	}

}

