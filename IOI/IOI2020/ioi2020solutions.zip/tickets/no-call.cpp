#include "tickets.h"
#include <vector>

long long find_maximum(int k, std::vector<std::vector<int>> x) {
	return 1;
}
