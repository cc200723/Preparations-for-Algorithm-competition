public class tickets {
	long find_maximum(int k, int[][] x) {
		return 1;
	}

}

