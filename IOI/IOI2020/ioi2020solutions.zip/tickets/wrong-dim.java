public class tickets {
	long find_maximum(int k, int[][] x) {
		grader.allocate_tickets(new int[1][1]);
		return 1;
	}

}

